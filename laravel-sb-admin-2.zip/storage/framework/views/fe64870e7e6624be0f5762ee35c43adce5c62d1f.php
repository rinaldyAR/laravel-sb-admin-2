

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4"><?php echo e(__('Verify Your Email Address')); ?></h1>
                                </div>

                                <?php if(session('resent')): ?>
                                    <div class="alert alert-success border-left-success" role="alert">
                                        <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                                <?php echo e(__('If you did not receive the email')); ?>, <a href="<?php echo e(route('verification.resend')); ?>" onclick="event.preventDefault(); document.getElementById('resend').submit();"><?php echo e(__('click here to request another')); ?></a>.
                                <form id="resend" action="<?php echo e(route('verification.resend')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rinaldy\Documents\laravel-sb-admin-2\resources\views/auth/verify.blade.php ENDPATH**/ ?>