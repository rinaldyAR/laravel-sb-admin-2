<?php $__env->startSection('main-content'); ?>

    <!-- Page Heading -->

    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Kelas Aktif')); ?></h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $widget['classes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Earnings (Monthly) Card Example -->

            <div class="col-xl-12 col-md-12 mb-4">
            <a href="/detailkelas/<?php echo e($class->id); ?>" style="text-decoration : none">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e($class->batch_start_date); ?> - <?php echo e($class->batch_end_date); ?></div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(ucfirst($class->classname)); ?> </div>
                            <div class="text-xs text-gray-600 mb-1">Level <?php echo e($class->classlevel); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                </a>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rinaldy\Documents\laravel-sb-admin-2\resources\views/adminhome.blade.php ENDPATH**/ ?>