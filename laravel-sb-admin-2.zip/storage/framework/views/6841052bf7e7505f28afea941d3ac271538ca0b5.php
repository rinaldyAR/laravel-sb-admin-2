<?php $__env->startSection('main-content'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Daftar Siswa Belum Bayar')); ?></h1>


    <?php if(session('success')): ?>
    <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <form class="d-none d-sm-inline-block form-inline navbar-search mb-2" style="width: 100%">
            <div class="input-group">
                <input type="text" class="form-control border-0 small" placeholder="Nama siswa" aria-label="Search" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                    </button>
                </div>
            </div>
        </form>
        <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Kelas</th>
                <th scope="col">Batch</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$sis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($sis->name); ?> <?php echo e($sis->last_name); ?></td>
                    <td><?php echo e($sis->classname); ?> level <?php echo e($sis->classlevel); ?></td>
                    <td><?php echo e($sis->batch_start_date); ?> - <?php echo e($sis->batch_end_date); ?></td>
                    <td scope="row">
                        <button id="<?php echo e($sis->id); ?>" type="button" class="openmodalbayar btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModalCenter">
                        Konfirmasi
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>

    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-body my-3">
                Apakah anda yakin untuk mengkonfirmasi pembayaran ini?
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
              <a href="" id="formkonfirm" name = "formkonfirm" class="btn btn-sm  btn-primary">Konfirm</a>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modalbayar'); ?>
<script>
    $(document).on("click", ".openmodalbayar", function () {
        $('#formkonfirm').attr('href', '/konfirm/' + $(this)[0]['id']);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rinaldy\Documents\laravel-sb-admin-2\resources\views/adminpembayaran.blade.php ENDPATH**/ ?>