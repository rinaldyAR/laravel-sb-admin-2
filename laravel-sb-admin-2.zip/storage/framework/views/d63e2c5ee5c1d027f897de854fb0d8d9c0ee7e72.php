<?php $__env->startSection('main-content'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($data['classes']->classname); ?></h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="">
        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
              <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Detail</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Tugas</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-materi" role="tab" aria-controls="nav-profile" aria-selected="false">Materi</a>
              <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-siswa" role="tab" aria-controls="nav-profile" aria-selected="false">Siswa</a>
            </div>
          </nav>
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                <table class="table table-borderless">
                    <tbody>
                      <tr>
                        <td style="width: 15%">Nama Kelas:</td>
                        <td style="width: 85%"><?php echo e($data['classes']->classname); ?></td>
                      </tr>
                      <tr>
                        <td>Deskripsi:</td>
                        <td><?php echo e($data['classes']->classdescription); ?></td>
                      </tr>
                      <tr>
                        <td>Level Kelas:</td>
                        <td><?php echo e($data['classes']->classlevel); ?></td>
                      </tr>
                      <tr>
                        <td>Tanggal Mulai Kelas:</td>
                        <td><?php echo e($data['classes']->batch_start_date); ?></td>
                      </tr>
                      <tr>
                        <td>Tanggal Selesai Kelas:</td>
                        <td><?php echo e($data['classes']->batch_end_date); ?></td>
                      </tr>
                    </tbody>
                  </table>
            </div>
            <div style="padding: 1rem" class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                <div class="btn btn-sm btn-primary float-right mb-2" data-toggle="modal" data-target="#tambahtugas">tugas baru</div>
                <table class="table">
                    <thead class="thead-light">
                      <tr >
                        <th scope="col">Tugas</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Materi</th>
                        <th scope="col">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                            ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                        </td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas</td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                    </tbody>
                  </table>
            </div>
            <div style="padding: 1rem" class="tab-pane fade" id="nav-materi" role="tabpanel" aria-labelledby="nav-profile-tab">
                <div class="btn btn-sm btn-primary float-right mb-2" data-toggle="modal" data-target="#tambahtugas">tugas baru</div>
                <table class="table">
                    <thead class="thead-light">
                      <tr >
                        <th scope="col">Tugas</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Materi</th>
                        <th scope="col">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                            ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                        </td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas</td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                    </tbody>
                  </table>
            </div>
            <div style="padding: 1rem" class="tab-pane fade" id="nav-siswa" role="tabpanel" aria-labelledby="nav-profile-tab">
                <div class="btn btn-sm btn-primary float-right mb-2" data-toggle="modal" data-target="#tambahtugas">tugas baru</div>
                <table class="table">
                    <thead class="thead-light">
                      <tr >
                        <th scope="col">Tugas</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Materi</th>
                        <th scope="col">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                            ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas ini deskripsi tugas
                        </td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                      <tr>
                        <td>Korea 1</td>
                        <td>ini deskripsi tugas</td>
                        <td>link pdf materi</td>
                        <td><button class="btn btn-sm btn-warning">update</button></td>
                      </tr>
                    </tbody>
                  </table>
            </div>
        </div>

    </div>

    <div class="modal fade" id="tambahtugas" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalCenterTitle">Tugas Baru</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <form role="form" action="/tugas" method="POST">
                        <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control" id="batch_id" name = "batch_id" value="<?php echo e($data['classes']->batch_id); ?>">
                            <div class="form-group">
                              <label for="nama">Nama Tugas</label>
                              <input type="text" class="form-control" id="name" name = "name" placeholder="Nama Batch">
                            </div>
                            <div class="form-group">
                              <label for="description">Deskripsi Tugas</label>
                              <textarea class="form-control" id="description" name = "description" placeholder="Deskripsi Batch" cols="20" rows="5"></textarea>
                            </div>

                            <div class="float-right">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                    </form>
                </div>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('dropdown'); ?>
<script>
$(document).ready(function(){
    $(".dropdown-menu a").click(function(){
        $(this).parents(".dropdown").find('.btn').html($(this).text() + ' <span class="caret"></span>' + '<div id="theid" style="display: none;"></div>');
        $(this).parents(".dropdown").find('.btn').val($(this).data('value'));
        //console.log($(this)[0]['id'])
        document.getElementById('theid').innerHTML = $(this)[0]['id'];
        console.log(document.getElementById('theid').innerHTML);
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rinaldy\Documents\laravel-sb-admin-2\resources\views/admindetail.blade.php ENDPATH**/ ?>